import firebase from 'firebase/app';
import 'firebase/auth'

const firebaseConfig = {
  // apiKey: "AIzaSyCcoCUdGLak6isXxhE6b9QKCG5T_-B9Eto",
  // authDomain: "otp-app-9554d.firebaseapp.com",
  // projectId: "otp-app-9554d",
  // storageBucket: "otp-app-9554d.appspot.com",
  // messagingSenderId: "106262004003",
  // appId: "1:106262004003:web:a000d96ec913208619cc96"
};

// Initialize Firebase

const firebase_demo = null
// firebase.default.initializeApp(firebaseConfig);
  
export default firebase_demo
