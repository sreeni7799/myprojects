import ProfileDetails from "./ProfileDetails"
import React from "react";
const ProfileOverlay = () => {
    return (
        <div>
            <ProfileDetails />
        </div>
    )
}

export default ProfileOverlay;