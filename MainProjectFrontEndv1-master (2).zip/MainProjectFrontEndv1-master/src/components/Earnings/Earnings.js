import Header from './Header/Header'
import classes from './Earnings.module.css'
import LineChart from './LineChart/LineChart';
import React, { Fragment } from 'react';
import { Data } from './LineChart/Data';


const Earnings = () => {
    return(
       
           <Fragment>
        <Header></Header>
       
        {/* <LineChart></LineChart> */}
        </Fragment>
      )
}
export default Earnings;