import React from 'react'
import { Fragment } from 'react'
import Header from '../Header/Header'
import Navigation from '../Navigation/Navigation'
const ForemanAuction = () => {
        return (
            <Fragment>
                <Header/>  
                <Navigation />
                Auction
            </Fragment>
        )
    
}

export default ForemanAuction;