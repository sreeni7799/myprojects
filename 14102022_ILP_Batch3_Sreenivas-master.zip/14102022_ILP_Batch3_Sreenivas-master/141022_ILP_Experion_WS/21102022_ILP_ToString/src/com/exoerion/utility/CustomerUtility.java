package com.exoerion.utility;

import com.experion.entity.Customer;

public class CustomerUtility {

	public static void main(String[] args) {
		Customer customer=new Customer("UHWDishd","ripwf");// TODO Auto-generated method stub
		System.out.println(customer);
	}

}
