package com.ilpexperion.ObjectClassBasics;

public class EmployeeUtility {

	public static void main(String[] args) {
		
		Employee employee=new Employee();
		employee.displayEmployeeDetails();
		// TODO Auto-generated method stub

	}

}
