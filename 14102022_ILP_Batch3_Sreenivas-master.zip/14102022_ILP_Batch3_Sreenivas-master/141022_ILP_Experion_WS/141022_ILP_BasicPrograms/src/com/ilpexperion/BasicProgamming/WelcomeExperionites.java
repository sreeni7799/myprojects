package com.ilpexperion.BasicProgamming;

public class WelcomeExperionites {

	public static void main(String[] args) {
		
		System.out.println("Welcome to ILP Experion");// TODO Auto-generated method stub

	}

}
