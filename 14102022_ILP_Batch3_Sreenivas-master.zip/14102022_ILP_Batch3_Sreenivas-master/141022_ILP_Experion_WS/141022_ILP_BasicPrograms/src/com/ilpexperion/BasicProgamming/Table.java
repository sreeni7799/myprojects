package com.ilpexperion.BasicProgamming;

public class Table {

	public static void main(String[] args) {

		String trainingProgram = "*******Welcome to ILP Program*******\n";// TODO Auto-generated method stub
		String employeeName = "Sreenivas";
		int employeeAge = 23;
		char employeeSex = 'M';
		double employeeCgpa = 9.5;
		System.out.println(trainingProgram);
		System.out.println("Name" + "			" + "Age" + "		" + "Sex" + "		" + "Cgpa");
		System.out.println(employeeName + "		" + employeeAge + "		" + employeeSex + "		" + employeeCgpa);

	}

}
