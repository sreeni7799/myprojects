package com.experion.service;

public interface LoanService {
	
	public abstract void loanDueDate();
	public void loanApproval();

}
