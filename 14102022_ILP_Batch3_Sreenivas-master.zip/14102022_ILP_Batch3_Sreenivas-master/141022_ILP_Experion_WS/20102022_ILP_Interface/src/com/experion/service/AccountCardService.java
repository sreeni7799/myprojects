package com.experion.service;

public interface AccountCardService {
	
	public abstract void checkBalance();
	
	public abstract void cashWithdrawal();
		
	}

