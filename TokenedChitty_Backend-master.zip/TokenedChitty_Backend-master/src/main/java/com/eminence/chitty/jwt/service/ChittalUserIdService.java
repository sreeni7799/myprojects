package com.eminence.chitty.jwt.service;

import java.util.List;
import java.util.Set;

public interface ChittalUserIdService {

    Set<String> getChitties(Long id);
}
