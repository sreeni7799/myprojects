package com.eminence.chitty.jwt.service;


import com.eminence.chitty.jwt.dto.NomineePost;

public interface NomineeService {

    NomineePost addNominee(NomineePost request);
//    ChittyPost updateChitty(ChittyPost request);
//    public Optional<Chitty> findById(Long chitNumber);
//    void deleteChitty(Long id);





}
