package com.eminence.chitty.jwt.service;


import com.eminence.chitty.jwt.dto.ChittalPost;
import com.eminence.chitty.jwt.dto.ChittalPostResponse;

public interface ChittalService {

    ChittalPostResponse addChittal(ChittalPost request);
//    ChittyPost updateChitty(ChittyPost request);
//    public Optional<Chitty> findById(Long chitNumber);
//    void deleteChitty(Long id);





}
