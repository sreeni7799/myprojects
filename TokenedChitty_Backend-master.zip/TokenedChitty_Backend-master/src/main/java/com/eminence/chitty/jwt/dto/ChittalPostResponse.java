package com.eminence.chitty.jwt.dto;

import lombok.Data;

@Data
public class ChittalPostResponse {
    private final Long chittalId;
}
